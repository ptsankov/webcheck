#
# TABLE STRUCTURE FOR: bamboo_clientcontacts
#

DROP TABLE IF EXISTS bamboo_clientcontacts;

CREATE TABLE `bamboo_clientcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_clientcontacts (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: bamboo_clients
#

DROP TABLE IF EXISTS bamboo_clients;

CREATE TABLE `bamboo_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext,
  `tax_code` varchar(75) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_histories
#

DROP TABLE IF EXISTS bamboo_invoice_histories;

CREATE TABLE `bamboo_invoice_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `clientcontacts_id` varchar(255) DEFAULT NULL,
  `date_sent` date DEFAULT NULL,
  `contact_type` int(1) DEFAULT NULL,
  `email_body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_items
#

DROP TABLE IF EXISTS bamboo_invoice_items;

CREATE TABLE `bamboo_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `amount` decimal(11,2) DEFAULT '0.00',
  `quantity` decimal(7,2) DEFAULT '1.00',
  `work_description` mediumtext,
  `taxable` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_payments
#

DROP TABLE IF EXISTS bamboo_invoice_payments;

CREATE TABLE `bamboo_invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` float(7,2) DEFAULT NULL,
  `payment_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoices
#

DROP TABLE IF EXISTS bamboo_invoices;

CREATE TABLE `bamboo_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `dateIssued` date DEFAULT NULL,
  `payment_term` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,3) DEFAULT NULL,
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,3) DEFAULT NULL,
  `invoice_note` text,
  `days_payment_due` int(3) unsigned DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_sessions
#

DROP TABLE IF EXISTS bamboo_sessions;

CREATE TABLE `bamboo_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) DEFAULT '',
  `last_activity` int(10) unsigned DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_data` text,
  `logged_in` int(1) DEFAULT '0',
  PRIMARY KEY (`session_id`,`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_settings
#

DROP TABLE IF EXISTS bamboo_settings;

CREATE TABLE `bamboo_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `primary_contact` varchar(75) DEFAULT NULL,
  `primary_contact_email` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `logo_pdf` varchar(50) DEFAULT NULL,
  `invoice_note_default` varchar(255) DEFAULT NULL,
  `currency_type` varchar(20) DEFAULT NULL,
  `currency_symbol` varchar(9) DEFAULT '$',
  `tax_code` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) DEFAULT 'n',
  `display_branding` char(1) DEFAULT 'y',
  `bambooinvoice_version` varchar(9) DEFAULT NULL,
  `new_version_autocheck` char(1) DEFAULT 'n',
  `logo_realpath` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_settings (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_0
#

DROP TABLE IF EXISTS result_0;

CREATE TABLE `result_0` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_0 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_1
#

DROP TABLE IF EXISTS result_1;

CREATE TABLE `result_1` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_1 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_10
#

DROP TABLE IF EXISTS result_10;

CREATE TABLE `result_10` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_10 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_11
#

DROP TABLE IF EXISTS result_11;

CREATE TABLE `result_11` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_11 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_12
#

DROP TABLE IF EXISTS result_12;

CREATE TABLE `result_12` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_12 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_13
#

DROP TABLE IF EXISTS result_13;

CREATE TABLE `result_13` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_13 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_14
#

DROP TABLE IF EXISTS result_14;

CREATE TABLE `result_14` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_14 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_15
#

DROP TABLE IF EXISTS result_15;

CREATE TABLE `result_15` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_15 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_16
#

DROP TABLE IF EXISTS result_16;

CREATE TABLE `result_16` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_16 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_17
#

DROP TABLE IF EXISTS result_17;

CREATE TABLE `result_17` (
  `id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_17 (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: result_18
#

DROP TABLE IF EXISTS result_18;

CREATE TABLE `result_18` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext CHARACTER SET utf8,
  `tax_code` varchar(75) CHARACTER SET utf8 DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: result_19
#

DROP TABLE IF EXISTS result_19;

CREATE TABLE `result_19` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_19 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_2
#

DROP TABLE IF EXISTS result_2;

CREATE TABLE `result_2` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_2 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_3
#

DROP TABLE IF EXISTS result_3;

CREATE TABLE `result_3` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_3 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_4
#

DROP TABLE IF EXISTS result_4;

CREATE TABLE `result_4` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_4 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_5
#

DROP TABLE IF EXISTS result_5;

CREATE TABLE `result_5` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_5 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_6
#

DROP TABLE IF EXISTS result_6;

CREATE TABLE `result_6` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_6 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_7
#

DROP TABLE IF EXISTS result_7;

CREATE TABLE `result_7` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_7 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_8
#

DROP TABLE IF EXISTS result_8;

CREATE TABLE `result_8` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_8 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_9
#

DROP TABLE IF EXISTS result_9;

CREATE TABLE `result_9` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_9 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


