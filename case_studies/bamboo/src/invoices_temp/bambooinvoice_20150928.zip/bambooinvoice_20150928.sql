#
# TABLE STRUCTURE FOR: bamboo_clientcontacts
#

DROP TABLE IF EXISTS bamboo_clientcontacts;

CREATE TABLE `bamboo_clientcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_clientcontacts (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'Wyk=', 1, NULL, 1433349830, '');


#
# TABLE STRUCTURE FOR: bamboo_clients
#

DROP TABLE IF EXISTS bamboo_clients;

CREATE TABLE `bamboo_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext,
  `tax_code` varchar(75) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_clients (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES (1, '1', '1', '1', '1', '1', '1', '1', '1', 1, NULL, '1');
INSERT INTO bamboo_clients (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES (2, '1', '1', '1', '1', '1', '1', '1', '1', 1, NULL, '1');
INSERT INTO bamboo_clients (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES (3, '1', '1', '1', '1', '1', '1', '1', '1', 1, NULL, '1');


#
# TABLE STRUCTURE FOR: bamboo_invoice_histories
#

DROP TABLE IF EXISTS bamboo_invoice_histories;

CREATE TABLE `bamboo_invoice_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `clientcontacts_id` varchar(255) DEFAULT NULL,
  `date_sent` date DEFAULT NULL,
  `contact_type` int(1) DEFAULT NULL,
  `email_body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_items
#

DROP TABLE IF EXISTS bamboo_invoice_items;

CREATE TABLE `bamboo_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `amount` decimal(11,2) DEFAULT '0.00',
  `quantity` decimal(7,2) DEFAULT '1.00',
  `work_description` mediumtext,
  `taxable` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_payments
#

DROP TABLE IF EXISTS bamboo_invoice_payments;

CREATE TABLE `bamboo_invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` float(7,2) DEFAULT NULL,
  `payment_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoices
#

DROP TABLE IF EXISTS bamboo_invoices;

CREATE TABLE `bamboo_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `dateIssued` date DEFAULT NULL,
  `payment_term` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,3) DEFAULT NULL,
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,3) DEFAULT NULL,
  `invoice_note` text,
  `days_payment_due` int(3) unsigned DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_sessions
#

DROP TABLE IF EXISTS bamboo_sessions;

CREATE TABLE `bamboo_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) DEFAULT '',
  `last_activity` int(10) unsigned DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_data` text,
  `logged_in` int(1) DEFAULT '0',
  PRIMARY KEY (`session_id`,`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_settings
#

DROP TABLE IF EXISTS bamboo_settings;

CREATE TABLE `bamboo_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `primary_contact` varchar(75) DEFAULT NULL,
  `primary_contact_email` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `logo_pdf` varchar(50) DEFAULT NULL,
  `invoice_note_default` varchar(255) DEFAULT NULL,
  `currency_type` varchar(20) DEFAULT NULL,
  `currency_symbol` varchar(9) DEFAULT '$',
  `tax_code` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) DEFAULT 'n',
  `display_branding` char(1) DEFAULT 'y',
  `bambooinvoice_version` varchar(9) DEFAULT NULL,
  `new_version_autocheck` char(1) DEFAULT 'n',
  `logo_realpath` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_settings (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


