#
# TABLE STRUCTURE FOR: bamboo_clientcontacts
#

DROP TABLE IF EXISTS bamboo_clientcontacts;

CREATE TABLE `bamboo_clientcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_clientcontacts (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: bamboo_clients
#

DROP TABLE IF EXISTS bamboo_clients;

CREATE TABLE `bamboo_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext,
  `tax_code` varchar(75) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_histories
#

DROP TABLE IF EXISTS bamboo_invoice_histories;

CREATE TABLE `bamboo_invoice_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `clientcontacts_id` varchar(255) DEFAULT NULL,
  `date_sent` date DEFAULT NULL,
  `contact_type` int(1) DEFAULT NULL,
  `email_body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_items
#

DROP TABLE IF EXISTS bamboo_invoice_items;

CREATE TABLE `bamboo_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `amount` decimal(11,2) DEFAULT '0.00',
  `quantity` decimal(7,2) DEFAULT '1.00',
  `work_description` mediumtext,
  `taxable` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoice_payments
#

DROP TABLE IF EXISTS bamboo_invoice_payments;

CREATE TABLE `bamboo_invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` float(7,2) DEFAULT NULL,
  `payment_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_invoices
#

DROP TABLE IF EXISTS bamboo_invoices;

CREATE TABLE `bamboo_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `dateIssued` date DEFAULT NULL,
  `payment_term` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,3) DEFAULT NULL,
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,3) DEFAULT NULL,
  `invoice_note` text,
  `days_payment_due` int(3) unsigned DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_sessions
#

DROP TABLE IF EXISTS bamboo_sessions;

CREATE TABLE `bamboo_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) DEFAULT '',
  `last_activity` int(10) unsigned DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_data` text,
  `logged_in` int(1) DEFAULT '0',
  PRIMARY KEY (`session_id`,`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bamboo_settings
#

DROP TABLE IF EXISTS bamboo_settings;

CREATE TABLE `bamboo_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `primary_contact` varchar(75) DEFAULT NULL,
  `primary_contact_email` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `logo_pdf` varchar(50) DEFAULT NULL,
  `invoice_note_default` varchar(255) DEFAULT NULL,
  `currency_type` varchar(20) DEFAULT NULL,
  `currency_symbol` varchar(9) DEFAULT '$',
  `tax_code` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) DEFAULT 'n',
  `display_branding` char(1) DEFAULT 'y',
  `bambooinvoice_version` varchar(9) DEFAULT NULL,
  `new_version_autocheck` char(1) DEFAULT 'n',
  `logo_realpath` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO bamboo_settings (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_0
#

DROP TABLE IF EXISTS result_0;

CREATE TABLE `result_0` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_0 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_1
#

DROP TABLE IF EXISTS result_1;

CREATE TABLE `result_1` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_1 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_10
#

DROP TABLE IF EXISTS result_10;

CREATE TABLE `result_10` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_10 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_100
#

DROP TABLE IF EXISTS result_100;

CREATE TABLE `result_100` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_100 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_101
#

DROP TABLE IF EXISTS result_101;

CREATE TABLE `result_101` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_101 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_102
#

DROP TABLE IF EXISTS result_102;

CREATE TABLE `result_102` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_102 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_103
#

DROP TABLE IF EXISTS result_103;

CREATE TABLE `result_103` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_103 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_104
#

DROP TABLE IF EXISTS result_104;

CREATE TABLE `result_104` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_104 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_105
#

DROP TABLE IF EXISTS result_105;

CREATE TABLE `result_105` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_105 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_106
#

DROP TABLE IF EXISTS result_106;

CREATE TABLE `result_106` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_106 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_107
#

DROP TABLE IF EXISTS result_107;

CREATE TABLE `result_107` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_107 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_108
#

DROP TABLE IF EXISTS result_108;

CREATE TABLE `result_108` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_108 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_109
#

DROP TABLE IF EXISTS result_109;

CREATE TABLE `result_109` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_109 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_11
#

DROP TABLE IF EXISTS result_11;

CREATE TABLE `result_11` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_11 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_110
#

DROP TABLE IF EXISTS result_110;

CREATE TABLE `result_110` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_110 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_111
#

DROP TABLE IF EXISTS result_111;

CREATE TABLE `result_111` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_111 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_112
#

DROP TABLE IF EXISTS result_112;

CREATE TABLE `result_112` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_112 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_113
#

DROP TABLE IF EXISTS result_113;

CREATE TABLE `result_113` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_113 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_114
#

DROP TABLE IF EXISTS result_114;

CREATE TABLE `result_114` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_114 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_115
#

DROP TABLE IF EXISTS result_115;

CREATE TABLE `result_115` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_115 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_116
#

DROP TABLE IF EXISTS result_116;

CREATE TABLE `result_116` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_116 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_117
#

DROP TABLE IF EXISTS result_117;

CREATE TABLE `result_117` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_117 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_118
#

DROP TABLE IF EXISTS result_118;

CREATE TABLE `result_118` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_118 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_119
#

DROP TABLE IF EXISTS result_119;

CREATE TABLE `result_119` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_119 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_12
#

DROP TABLE IF EXISTS result_12;

CREATE TABLE `result_12` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_12 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_120
#

DROP TABLE IF EXISTS result_120;

CREATE TABLE `result_120` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_120 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_121
#

DROP TABLE IF EXISTS result_121;

CREATE TABLE `result_121` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_121 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_122
#

DROP TABLE IF EXISTS result_122;

CREATE TABLE `result_122` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_122 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_123
#

DROP TABLE IF EXISTS result_123;

CREATE TABLE `result_123` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_123 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_124
#

DROP TABLE IF EXISTS result_124;

CREATE TABLE `result_124` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_124 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_125
#

DROP TABLE IF EXISTS result_125;

CREATE TABLE `result_125` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_125 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_126
#

DROP TABLE IF EXISTS result_126;

CREATE TABLE `result_126` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_126 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_127
#

DROP TABLE IF EXISTS result_127;

CREATE TABLE `result_127` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_127 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_128
#

DROP TABLE IF EXISTS result_128;

CREATE TABLE `result_128` (
  `id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_128 (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: result_129
#

DROP TABLE IF EXISTS result_129;

CREATE TABLE `result_129` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext CHARACTER SET utf8,
  `tax_code` varchar(75) CHARACTER SET utf8 DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: result_13
#

DROP TABLE IF EXISTS result_13;

CREATE TABLE `result_13` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_13 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_130
#

DROP TABLE IF EXISTS result_130;

CREATE TABLE `result_130` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_130 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_131
#

DROP TABLE IF EXISTS result_131;

CREATE TABLE `result_131` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_131 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_132
#

DROP TABLE IF EXISTS result_132;

CREATE TABLE `result_132` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_132 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_133
#

DROP TABLE IF EXISTS result_133;

CREATE TABLE `result_133` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_133 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_134
#

DROP TABLE IF EXISTS result_134;

CREATE TABLE `result_134` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_134 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_135
#

DROP TABLE IF EXISTS result_135;

CREATE TABLE `result_135` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_135 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_136
#

DROP TABLE IF EXISTS result_136;

CREATE TABLE `result_136` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_136 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_137
#

DROP TABLE IF EXISTS result_137;

CREATE TABLE `result_137` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_137 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_138
#

DROP TABLE IF EXISTS result_138;

CREATE TABLE `result_138` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_138 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_139
#

DROP TABLE IF EXISTS result_139;

CREATE TABLE `result_139` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_139 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_14
#

DROP TABLE IF EXISTS result_14;

CREATE TABLE `result_14` (
  `id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_14 (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: result_140
#

DROP TABLE IF EXISTS result_140;

CREATE TABLE `result_140` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_140 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_141
#

DROP TABLE IF EXISTS result_141;

CREATE TABLE `result_141` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_141 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_142
#

DROP TABLE IF EXISTS result_142;

CREATE TABLE `result_142` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_142 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_143
#

DROP TABLE IF EXISTS result_143;

CREATE TABLE `result_143` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_143 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_144
#

DROP TABLE IF EXISTS result_144;

CREATE TABLE `result_144` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_144 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_145
#

DROP TABLE IF EXISTS result_145;

CREATE TABLE `result_145` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_145 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_146
#

DROP TABLE IF EXISTS result_146;

CREATE TABLE `result_146` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_146 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_147
#

DROP TABLE IF EXISTS result_147;

CREATE TABLE `result_147` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_147 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_148
#

DROP TABLE IF EXISTS result_148;

CREATE TABLE `result_148` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_148 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_149
#

DROP TABLE IF EXISTS result_149;

CREATE TABLE `result_149` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_149 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_15
#

DROP TABLE IF EXISTS result_15;

CREATE TABLE `result_15` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext CHARACTER SET utf8,
  `tax_code` varchar(75) CHARACTER SET utf8 DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: result_150
#

DROP TABLE IF EXISTS result_150;

CREATE TABLE `result_150` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_150 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_151
#

DROP TABLE IF EXISTS result_151;

CREATE TABLE `result_151` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_151 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_152
#

DROP TABLE IF EXISTS result_152;

CREATE TABLE `result_152` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_152 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_153
#

DROP TABLE IF EXISTS result_153;

CREATE TABLE `result_153` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_153 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_154
#

DROP TABLE IF EXISTS result_154;

CREATE TABLE `result_154` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_154 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_155
#

DROP TABLE IF EXISTS result_155;

CREATE TABLE `result_155` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_155 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_156
#

DROP TABLE IF EXISTS result_156;

CREATE TABLE `result_156` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_156 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_157
#

DROP TABLE IF EXISTS result_157;

CREATE TABLE `result_157` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_157 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_158
#

DROP TABLE IF EXISTS result_158;

CREATE TABLE `result_158` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_158 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_159
#

DROP TABLE IF EXISTS result_159;

CREATE TABLE `result_159` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_159 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_16
#

DROP TABLE IF EXISTS result_16;

CREATE TABLE `result_16` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_16 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_160
#

DROP TABLE IF EXISTS result_160;

CREATE TABLE `result_160` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_160 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_161
#

DROP TABLE IF EXISTS result_161;

CREATE TABLE `result_161` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_161 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_162
#

DROP TABLE IF EXISTS result_162;

CREATE TABLE `result_162` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_162 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_163
#

DROP TABLE IF EXISTS result_163;

CREATE TABLE `result_163` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_163 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_164
#

DROP TABLE IF EXISTS result_164;

CREATE TABLE `result_164` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_164 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_165
#

DROP TABLE IF EXISTS result_165;

CREATE TABLE `result_165` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_165 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_166
#

DROP TABLE IF EXISTS result_166;

CREATE TABLE `result_166` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_166 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_167
#

DROP TABLE IF EXISTS result_167;

CREATE TABLE `result_167` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_167 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_168
#

DROP TABLE IF EXISTS result_168;

CREATE TABLE `result_168` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_168 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_169
#

DROP TABLE IF EXISTS result_169;

CREATE TABLE `result_169` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_169 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_17
#

DROP TABLE IF EXISTS result_17;

CREATE TABLE `result_17` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_17 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_170
#

DROP TABLE IF EXISTS result_170;

CREATE TABLE `result_170` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_170 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_18
#

DROP TABLE IF EXISTS result_18;

CREATE TABLE `result_18` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_18 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_19
#

DROP TABLE IF EXISTS result_19;

CREATE TABLE `result_19` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_19 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_2
#

DROP TABLE IF EXISTS result_2;

CREATE TABLE `result_2` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_2 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_20
#

DROP TABLE IF EXISTS result_20;

CREATE TABLE `result_20` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_20 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_21
#

DROP TABLE IF EXISTS result_21;

CREATE TABLE `result_21` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_21 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_22
#

DROP TABLE IF EXISTS result_22;

CREATE TABLE `result_22` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_22 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_23
#

DROP TABLE IF EXISTS result_23;

CREATE TABLE `result_23` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_23 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_24
#

DROP TABLE IF EXISTS result_24;

CREATE TABLE `result_24` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_24 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_25
#

DROP TABLE IF EXISTS result_25;

CREATE TABLE `result_25` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_25 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_26
#

DROP TABLE IF EXISTS result_26;

CREATE TABLE `result_26` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_26 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_27
#

DROP TABLE IF EXISTS result_27;

CREATE TABLE `result_27` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_27 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_28
#

DROP TABLE IF EXISTS result_28;

CREATE TABLE `result_28` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_28 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_29
#

DROP TABLE IF EXISTS result_29;

CREATE TABLE `result_29` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_29 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_3
#

DROP TABLE IF EXISTS result_3;

CREATE TABLE `result_3` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_3 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_30
#

DROP TABLE IF EXISTS result_30;

CREATE TABLE `result_30` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_30 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_31
#

DROP TABLE IF EXISTS result_31;

CREATE TABLE `result_31` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_31 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_32
#

DROP TABLE IF EXISTS result_32;

CREATE TABLE `result_32` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_32 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_33
#

DROP TABLE IF EXISTS result_33;

CREATE TABLE `result_33` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_33 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_34
#

DROP TABLE IF EXISTS result_34;

CREATE TABLE `result_34` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_34 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_35
#

DROP TABLE IF EXISTS result_35;

CREATE TABLE `result_35` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_35 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_36
#

DROP TABLE IF EXISTS result_36;

CREATE TABLE `result_36` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_36 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_37
#

DROP TABLE IF EXISTS result_37;

CREATE TABLE `result_37` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_37 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_38
#

DROP TABLE IF EXISTS result_38;

CREATE TABLE `result_38` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_38 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_39
#

DROP TABLE IF EXISTS result_39;

CREATE TABLE `result_39` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_39 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_4
#

DROP TABLE IF EXISTS result_4;

CREATE TABLE `result_4` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_4 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_40
#

DROP TABLE IF EXISTS result_40;

CREATE TABLE `result_40` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_40 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_41
#

DROP TABLE IF EXISTS result_41;

CREATE TABLE `result_41` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_41 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_42
#

DROP TABLE IF EXISTS result_42;

CREATE TABLE `result_42` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_42 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_43
#

DROP TABLE IF EXISTS result_43;

CREATE TABLE `result_43` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_43 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_44
#

DROP TABLE IF EXISTS result_44;

CREATE TABLE `result_44` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_44 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_45
#

DROP TABLE IF EXISTS result_45;

CREATE TABLE `result_45` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_45 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_46
#

DROP TABLE IF EXISTS result_46;

CREATE TABLE `result_46` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_46 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_47
#

DROP TABLE IF EXISTS result_47;

CREATE TABLE `result_47` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_47 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_48
#

DROP TABLE IF EXISTS result_48;

CREATE TABLE `result_48` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_48 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_49
#

DROP TABLE IF EXISTS result_49;

CREATE TABLE `result_49` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_49 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_5
#

DROP TABLE IF EXISTS result_5;

CREATE TABLE `result_5` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_5 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_50
#

DROP TABLE IF EXISTS result_50;

CREATE TABLE `result_50` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_50 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_51
#

DROP TABLE IF EXISTS result_51;

CREATE TABLE `result_51` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_51 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_52
#

DROP TABLE IF EXISTS result_52;

CREATE TABLE `result_52` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_52 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_53
#

DROP TABLE IF EXISTS result_53;

CREATE TABLE `result_53` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_53 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_54
#

DROP TABLE IF EXISTS result_54;

CREATE TABLE `result_54` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_54 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_55
#

DROP TABLE IF EXISTS result_55;

CREATE TABLE `result_55` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_55 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_56
#

DROP TABLE IF EXISTS result_56;

CREATE TABLE `result_56` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_56 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_57
#

DROP TABLE IF EXISTS result_57;

CREATE TABLE `result_57` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_57 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_58
#

DROP TABLE IF EXISTS result_58;

CREATE TABLE `result_58` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_58 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_59
#

DROP TABLE IF EXISTS result_59;

CREATE TABLE `result_59` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_59 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_6
#

DROP TABLE IF EXISTS result_6;

CREATE TABLE `result_6` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_6 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_60
#

DROP TABLE IF EXISTS result_60;

CREATE TABLE `result_60` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_60 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_61
#

DROP TABLE IF EXISTS result_61;

CREATE TABLE `result_61` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_61 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_62
#

DROP TABLE IF EXISTS result_62;

CREATE TABLE `result_62` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_62 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_63
#

DROP TABLE IF EXISTS result_63;

CREATE TABLE `result_63` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_63 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_64
#

DROP TABLE IF EXISTS result_64;

CREATE TABLE `result_64` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_64 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_65
#

DROP TABLE IF EXISTS result_65;

CREATE TABLE `result_65` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_65 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_66
#

DROP TABLE IF EXISTS result_66;

CREATE TABLE `result_66` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_66 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_67
#

DROP TABLE IF EXISTS result_67;

CREATE TABLE `result_67` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_67 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_68
#

DROP TABLE IF EXISTS result_68;

CREATE TABLE `result_68` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_68 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_69
#

DROP TABLE IF EXISTS result_69;

CREATE TABLE `result_69` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_69 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_7
#

DROP TABLE IF EXISTS result_7;

CREATE TABLE `result_7` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_7 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_70
#

DROP TABLE IF EXISTS result_70;

CREATE TABLE `result_70` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_70 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_71
#

DROP TABLE IF EXISTS result_71;

CREATE TABLE `result_71` (
  `id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_71 (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES (1, 0, NULL, NULL, NULL, 'a@a.com', NULL, 'VSc=', 1, NULL, 1445116934, '');


#
# TABLE STRUCTURE FOR: result_72
#

DROP TABLE IF EXISTS result_72;

CREATE TABLE `result_72` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext CHARACTER SET utf8,
  `tax_code` varchar(75) CHARACTER SET utf8 DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: result_73
#

DROP TABLE IF EXISTS result_73;

CREATE TABLE `result_73` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_73 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_74
#

DROP TABLE IF EXISTS result_74;

CREATE TABLE `result_74` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_74 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_75
#

DROP TABLE IF EXISTS result_75;

CREATE TABLE `result_75` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_75 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_76
#

DROP TABLE IF EXISTS result_76;

CREATE TABLE `result_76` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_76 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_77
#

DROP TABLE IF EXISTS result_77;

CREATE TABLE `result_77` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_77 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_78
#

DROP TABLE IF EXISTS result_78;

CREATE TABLE `result_78` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_78 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_79
#

DROP TABLE IF EXISTS result_79;

CREATE TABLE `result_79` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_79 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_8
#

DROP TABLE IF EXISTS result_8;

CREATE TABLE `result_8` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_8 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_80
#

DROP TABLE IF EXISTS result_80;

CREATE TABLE `result_80` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_80 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_81
#

DROP TABLE IF EXISTS result_81;

CREATE TABLE `result_81` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_81 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_82
#

DROP TABLE IF EXISTS result_82;

CREATE TABLE `result_82` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_82 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_83
#

DROP TABLE IF EXISTS result_83;

CREATE TABLE `result_83` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_83 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_84
#

DROP TABLE IF EXISTS result_84;

CREATE TABLE `result_84` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_84 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_85
#

DROP TABLE IF EXISTS result_85;

CREATE TABLE `result_85` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_85 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_86
#

DROP TABLE IF EXISTS result_86;

CREATE TABLE `result_86` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_86 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_87
#

DROP TABLE IF EXISTS result_87;

CREATE TABLE `result_87` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_87 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_88
#

DROP TABLE IF EXISTS result_88;

CREATE TABLE `result_88` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_88 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_89
#

DROP TABLE IF EXISTS result_89;

CREATE TABLE `result_89` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_89 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_9
#

DROP TABLE IF EXISTS result_9;

CREATE TABLE `result_9` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_9 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_90
#

DROP TABLE IF EXISTS result_90;

CREATE TABLE `result_90` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_90 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_91
#

DROP TABLE IF EXISTS result_91;

CREATE TABLE `result_91` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_91 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_92
#

DROP TABLE IF EXISTS result_92;

CREATE TABLE `result_92` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_92 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_93
#

DROP TABLE IF EXISTS result_93;

CREATE TABLE `result_93` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_93 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_94
#

DROP TABLE IF EXISTS result_94;

CREATE TABLE `result_94` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_94 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_95
#

DROP TABLE IF EXISTS result_95;

CREATE TABLE `result_95` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_95 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_96
#

DROP TABLE IF EXISTS result_96;

CREATE TABLE `result_96` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_96 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_97
#

DROP TABLE IF EXISTS result_97;

CREATE TABLE `result_97` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_97 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_98
#

DROP TABLE IF EXISTS result_98;

CREATE TABLE `result_98` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_98 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


#
# TABLE STRUCTURE FOR: result_99
#

DROP TABLE IF EXISTS result_99;

CREATE TABLE `result_99` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `province` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `postal_code` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact` varchar(75) CHARACTER SET utf8 DEFAULT NULL,
  `primary_contact_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `logo_pdf` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `invoice_note_default` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `currency_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency_symbol` varchar(9) CHARACTER SET utf8 DEFAULT '$',
  `tax_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `display_branding` char(1) CHARACTER SET utf8 DEFAULT 'y',
  `bambooinvoice_version` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `new_version_autocheck` char(1) CHARACTER SET utf8 DEFAULT 'n',
  `logo_realpath` char(1) CHARACTER SET utf8 DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO result_99 (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', 'a@a.com', NULL, NULL, NULL, NULL, '$', NULL, NULL, '0.000', NULL, '0.000', 'n', 30, 'n', 'y', '0.8.9', 'y', 'n');


